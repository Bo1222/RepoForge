# Value function tests
