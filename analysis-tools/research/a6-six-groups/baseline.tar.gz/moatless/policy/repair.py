"""a6 acceptance ledger. Models propose obligations; execution facts discharge them.

This module only uses public issue text, workspace code and recorded executions.
It does not assign a probability of correctness or claim benchmark resolution.
"""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from moatless.execution_memory import environment_version, test_records
from moatless.message_history.policy import content_hash
from moatless.repository_overlay import CurrentRepository
from moatless.actions.test_targets import discover_test_targets, is_related_test
from moatless.utils.file import is_test


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class AcceptanceCriterion(StrictModel):
    id: str = Field(min_length=1, max_length=80)
    behavior: str = Field(min_length=8, max_length=2000)
    public_quote: str = Field(min_length=3, max_length=2000)
    kind: Literal["issue_behavior", "regression"] = "issue_behavior"


class CheckSpec(StrictModel):
    id: str = Field(min_length=1, max_length=80)
    criteria: list[str] = Field(min_length=1)
    targets: list[str] = Field(min_length=1, max_length=20)
    test_source: Literal["workspace", "base_public"] = "base_public"
    proof: Literal["fail_to_pass", "regression"] = "fail_to_pass"


class AcceptancePlan(StrictModel):
    version: Literal[1] = 1
    revision: int = Field(default=1, ge=1)
    criteria: list[AcceptanceCriterion] = Field(min_length=1, max_length=30)
    checks: list[CheckSpec] = Field(default_factory=list, max_length=60)

    @model_validator(mode="after")
    def valid_links(self):
        ids = [item.id for item in self.criteria]
        check_ids = [check.id for check in self.checks]
        if len(set(ids)) != len(ids) or len(set(check_ids)) != len(check_ids):
            raise ValueError("IDs must be unique")
        if not any(item.kind == "issue_behavior" for item in self.criteria):
            raise ValueError("At least one public issue behavior is required")
        for check in self.checks:
            if not set(check.criteria) <= set(ids):
                raise ValueError("Check refers to unknown criterion")
            if any(item.kind == "issue_behavior" and item.id in check.criteria for item in self.criteria) and check.proof != "fail_to_pass":
                raise ValueError("Issue behavior requires a public failing reproduction, not unrelated green tests")
        return self


class CompletionAssessment(StrictModel):
    version: Literal[1] = 1
    state: Literal["partial", "repair", "unavailable", "ready"] = "partial"
    outstanding: list[str] = Field(default_factory=list)
    failures: list[dict] = Field(default_factory=list)
    receipts: list[str] = Field(default_factory=list)
    next_check: dict | None = None
    patch_hash: str | None = None


class VerifiedCheckpoint(StrictModel):
    version: Literal[1] = 1
    product_patch: str
    patch_hash: str
    plan_revision: int
    receipt_sources: list[str]
    environment: str


def registered_plan(node) -> AcceptancePlan | None:
    for previous in reversed(node.get_trajectory()):
        for step in reversed(previous.action_steps):
            props = step.observation.properties if step.observation else {}
            if props and props.get("accepted_plan"):
                return AcceptancePlan.model_validate(props["accepted_plan"])
    return None


def validate_revision(node, plan):
    public_text = "\n".join(n.user_message for n in node.get_trajectory() if n.user_message)
    for item in plan.criteria:
        if item.public_quote not in public_text:
            raise ValueError(f"{item.id}: quote must occur verbatim in public task text")
    previous = registered_plan(node)
    if previous:
        if plan.revision != previous.revision + 1:
            raise ValueError("Revision must advance by one")
        old = {item.id: item for item in previous.criteria}
        new = {item.id: item for item in plan.criteria}
        if any(key not in new or new[key] != value for key, value in old.items()):
            raise ValueError("Existing acceptance obligations cannot be deleted or weakened; add a new criterion")
        checks = {check.id: check for check in plan.checks}
        if any(check.id not in checks or checks[check.id] != check for check in previous.checks):
            raise ValueError("Existing mandatory checks cannot be removed or changed; append a check")
    elif plan.revision != 1:
        raise ValueError("Initial plan revision must be 1")


def _request(check, product_source="current"):
    return {"test_files": check.targets, "test_source": check.test_source,
            "product_source": product_source, "check_id": check.id}


def _names(record, status):
    return {f"{result.get('file_path')}::{result.get('name')}" for result in record.get("results", [])
            if str(result.get("status", "")).lower() == status and result.get("name")}


def _complete(record):
    return (record.get("complete") is True and not record.get("timed_out")
            and not record.get("patch_stale") and record.get("input_identity")
            and record["workspace_before"] == record["workspace_after"]
            and record["environment_before"] == record["environment_after"])


def assess(node, workspace) -> CompletionAssessment:
    context = node.file_context
    product = context.generate_git_patch(ignore_tests=True) if context else ""
    digest = content_hash(product)
    result = CompletionAssessment(patch_hash=digest)
    if not product.strip():
        result.outstanding.append("product_patch")
    plan = registered_plan(node)
    if plan is None:
        result.outstanding.append("acceptance_plan")
        return result
    overlay = CurrentRepository(workspace.repository, context)
    changed = [f.file_path for f in context.files if f.patch and not is_test(f.file_path)]
    for path in changed:
        if path.endswith(".py"):
            try:
                compile(overlay.get_file_content(path) or "", path, "exec", dont_inherit=True)
            except (SyntaxError, ValueError) as exc:
                result.failures.append({"kind": "syntax_error", "file": path, "excerpt": str(exc)})
    records = test_records(node, workspace)
    env = environment_version(workspace)
    current = [r for r in records if not r["superseded"] and r.get("product_source") == "current"
               and r.get("product_patch_hash") == digest and r.get("environment_after") == env]
    # Any related actual failure blocks success, regardless of the last observation.
    for record in current:
        if record.get("effective_status") in {"failed", "error"} and not record.get("timed_out"):
            if any(is_related_test(overlay, path, changed) for path in record["targets"]) or any(
                    set(record["targets"]) == set(c.targets) for c in plan.checks):
                from moatless.policy.failures import interpret
                excerpt = "\n".join(str(r.get("failure_output") or "") for r in record.get("results", []))
                signal = interpret({"test_run": record}, excerpt)
                result.failures.append({"source_id": record["source_id"], "tests": record["targets"],
                    "kind": signal.kind.value if signal else "test_failure", "failing_tests": sorted(_names(record, "failed") | _names(record, "error")),
                    "excerpt": "\n".join(str(r.get("failure_output") or "")[-800:] for r in record.get("results", [])
                                            if str(r.get("status", "")).lower() in {"failed", "error"})[:1600]})
    satisfied = set()
    valid_public = False
    had_pending_check = False
    for check in plan.checks:
        source = workspace.repository if check.test_source == "base_public" else overlay
        bundle = content_hash({path: (context._files[path].get_base_content()
                        if check.test_source == "base_public" and path in context._files else source.get_file_content(path))
                        for path in check.targets})
        matching = [r for r in current if set(r["targets"]) == set(check.targets)
                    and r.get("test_source") == check.test_source and r.get("test_bundle_hash") == bundle]
        passes = [r for r in matching if _complete(r) and r.get("effective_status") == "passed"
                  and r.get("return_code") == 0 and r.get("counts", {}).get("passed", 0) > 0]
        if not passes:
            result.outstanding.append(check.id)
            had_pending_check = True
            if result.next_check is None and not result.failures:
                result.next_check = _request(check)
            continue
        receipt = passes[-1]
        result.receipts.append(receipt["source_id"])
        if check.proof == "fail_to_pass":
            baselines = [r for r in records if not r["superseded"] and _complete(r)
                and r.get("product_source") == "base" and r.get("test_source") == check.test_source
                and set(r["targets"]) == set(check.targets) and r.get("test_bundle_hash") == bundle
                and r.get("runner") == receipt.get("runner") and r.get("environment_after") == env]
            # Collection/import errors are not a behavioral reproduction.
            baselines = [r for r in baselines if r.get("status") == "failed" and r.get("return_code") == 1
                         and _names(r, "failed") and not r.get("counts", {}).get("error")]
            if not baselines or not _names(baselines[-1], "failed") <= _names(receipt, "passed"):
                result.outstanding.append(check.id + ":public_reproduction")
                if result.next_check is None:
                    result.next_check = _request(check, "base")
                continue
            result.receipts.append(baselines[-1]["source_id"])
        satisfied.update(check.criteria)
        valid_public |= check.test_source == "base_public" and any(is_related_test(overlay, path, changed) for path in check.targets)
    result.outstanding.extend(item.id for item in plan.criteria if item.id not in satisfied)
    # New/changed test evidence needs an additional check on original public tests.
    if not valid_public:
        result.outstanding.append("original_public_regression")
        if result.next_check is None and not result.failures:
            targets = discover_test_targets(workspace.repository, changed, require_relation=True)
            if targets:
                result.next_check = {"test_files": targets[:1], "test_source": "base_public"}
            # A controller-dispatched original public check can discharge this
            # requirement, but cannot discharge issue behavior criteria.
            public = [r for r in current if r.get("test_source") == "base_public" and _complete(r)
                      and r.get("effective_status") == "passed" and r.get("return_code") == 0
                      and any(is_related_test(overlay, p, changed) for p in r["targets"])]
            if public:
                result.outstanding.remove("original_public_regression")
                result.receipts.append(public[-1]["source_id"])
                if not had_pending_check:
                    result.next_check = None
    if result.failures:
        result.state, result.next_check = "repair", None
    elif not result.outstanding:
        result.state, result.next_check = "ready", None
    elif result.next_check is None:
        result.state = "unavailable"
    return result
