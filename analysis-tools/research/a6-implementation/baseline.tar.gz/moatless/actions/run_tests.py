import asyncio
import logging
import time
from typing import Literal

from pydantic import ConfigDict, Field, PrivateAttr

from moatless.actions.action import Action
from moatless.actions.schema import (
    ActionArguments,
    Observation,
    RewardScaleEntry,
)
from moatless.artifacts.artifact import ArtifactChange
from moatless.completion.schema import FewShotExample
from moatless.file_context import FileContext
from moatless.testing.schema import TestFile
from moatless.testing.schema import TestResult, TestStatus
from moatless.workspace import Workspace

logger = logging.getLogger(__name__)


class RunTestsArgs(ActionArguments):
    """
    Run the specified unit tests in the codebase.

    Note: This action requires explicit paths to test files.
    - Only full test file paths are supported (e.g., "tests/auth/test_login.py")
    - Directory paths, file patterns (e.g., "tests/*.py"), and individual test methods are NOT supported
    - Non-existent test files will be reported as errors
    """

    test_files: list[str] = Field(
        ..., description="The list of explicit test file paths to run (must be file paths, not directories or patterns)"
    )
    test_source: Literal["workspace", "base_public"] = Field(
        default="workspace", description="Use current tests, or unchanged public repository tests with only the product patch."
    )

    model_config = ConfigDict(title="RunTests")

    def model_dump(self, **kwargs):
        data = super().model_dump(**kwargs)
        if self.test_source == "workspace":
            data.pop("test_source", None)  # legacy action arguments remain readable and stable
        return data

    def model_dump_json(self, **kwargs):
        if self.test_source == "workspace":
            exclude = kwargs.get("exclude") or set()
            kwargs["exclude"] = {**exclude, "test_source": True} if isinstance(exclude, dict) else set(exclude) | {"test_source"}
        return super().model_dump_json(**kwargs)

    @property
    def log_name(self):
        return f"RunTests({', '.join(self.test_files)})"

    def to_prompt(self):
        return "Running tests for the following files:\n" + "\n".join(f"* {file}" for file in self.test_files)

    @classmethod
    def get_few_shot_examples(cls) -> list[FewShotExample]:
        return [
            FewShotExample.create(
                user_input="Run the tests for our user authentication module",
                action=RunTestsArgs(
                    thoughts="Running authentication tests to verify the login functionality works as expected",
                    test_files=["tests/auth/test_authentication.py", "tests/auth/test_login.py"],
                ),
            ),
            FewShotExample.create(
                user_input="After fixing the data validation bug, I need to make sure the validation tests pass",
                action=RunTestsArgs(
                    thoughts="Running validation tests to confirm that the bug fix resolved the issues with input validation",
                    test_files=["tests/validation/test_input_validator.py"],
                ),
            ),
        ]


class RunTests(Action):
    """
    Runs specified test files in the codebase.

    Important requirements:
    - Only accepts explicit, complete file paths to test files
    - Does not support directories, file patterns, or individual test methods
    - Will validate that test files exist before attempting to run them
    - Will report errors for non-existent files or if directories are specified
    """

    args_schema = RunTestsArgs
    _public_baselines: dict = PrivateAttr(default_factory=dict)

    max_output_tokens: int = Field(
        2000,
        description="The maximum number of tokens in the test result output message",
    )
    timeout: int = Field(
        110,
        description="Per-invocation wall-clock timeout in seconds; the job continues with a tool_timeout observation",
    )

    async def initialize(self, workspace: Workspace):
        await super().initialize(workspace)
        if not workspace.runtime:
            raise ValueError("Runtime is not available for RunTests action")

    async def execute(
        self,
        args: RunTestsArgs,
        file_context: FileContext | None = None,
    ) -> Observation:
        """
        Run all tests found in file context or provided in args.
        """
        if file_context is None:
            raise ValueError("File context must be provided to execute the run tests action.")

        # Ensure workspace is set on file_context if needed
        if not hasattr(file_context, "workspace") or file_context.workspace is None:
            if self._workspace:
                file_context.workspace = self._workspace

        non_existent_files = []
        directories = []
        test_files = []

        for test_file in args.test_files:
            test_file = test_file.split("::")[0]
            if not self._repository.file_exists(test_file) and not file_context.file_exists(test_file):
                logger.warning(f"File {test_file} does not exist in repository")
                non_existent_files.append(test_file)
            elif self._repository.is_directory(test_file):
                logger.warning(
                    f"Directory {test_file} provided instead of file, please use ListFiles to get the list of files in the directory and specify which files to run tests on"
                )
                directories.append(test_file)
            else:
                test_files.append(test_file)

        error_details = []
        if non_existent_files:
            error_details.append(f"Files not found: {', '.join(non_existent_files)}")
        if directories:
            error_details.append(f"Directories provided instead of files: {', '.join(directories)}")

        if not test_files:
            return Observation.create(
                message="Unable to run tests: " + "; ".join(error_details),
                properties={"test_results": [], "fail_reason": "no_test_files"},
            )

        from moatless.message_history.policy import content_hash
        origins, base_contents = {}, {}
        for path in test_files:
            file = file_context._files.get(path)
            base = file.get_base_content() if file else self._repository.get_file_content(path)
            base_contents[path] = base
            origins[path] = "original" if not file or base == file.content else "modified"
            if not base:
                origins[path] = "new"
        test_source = args.test_source
        auto_base_public = False
        product_patch = file_context.generate_git_patch(ignore_tests=True)
        origins_list = list(origins.values())
        if (test_source == "workspace" and product_patch
                and "modified" in origins_list and "new" not in origins_list):
            # Tests were edited.  The workspace result is self-fulfilling;
            # verify the product patch against the unchanged public tests.
            test_source = "base_public"
            auto_base_public = True
        if test_source == "base_public" and any(value == "new" for value in origins.values()):
            return Observation.create(message="base_public requires tests present in the repository base.",
                                      properties={"fail_reason": "no_test_files", "test_results": []})
        patch = file_context.generate_git_patch(ignore_tests=test_source == "base_public")
        product_patch_hash = content_hash(file_context.generate_git_patch(ignore_tests=True))
        start_time = time.time()
        try:
            test_results = await asyncio.wait_for(
                self._workspace.runtime.run_tests(test_files=test_files, patch=patch),
                timeout=self.timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("RunTests timed out after %s seconds", self.timeout)
            runtime = self._workspace.runtime
            executions = list(getattr(runtime, "last_test_execution", []) or [])
            partial = list(getattr(runtime, "last_test_results", []) or [])
            for execution in executions:
                target = execution.get("target")
                if execution.get("return_code") == -1 and not any(
                        result.file_path == target and result.timed_out for result in partial):
                    partial.append(TestResult(
                        status=TestStatus.ERROR, file_path=target, timed_out=True,
                        failure_output=f"Test execution timed out after {self.timeout} seconds",
                    ))
            return Observation.create(
                message=(
                    f"Tests did not finish within {self.timeout}s. "
                    "The job continues; narrow the target to a single file/test or use the partial results."
                    + (f" Completed files: {', '.join(str(item.get('target')) for item in executions)}."
                       if executions else "")
                ),
                properties={
                    "test_results": [result.model_dump() for result in partial],
                    "test_execution": executions,
                    "test_source": test_source,
                    "test_origins": origins,
                    "timed_out": True,
                    "fail_reason": "tool_timeout",
                    "product_patch_hash": product_patch_hash,
                    "product_patch": patch if test_source == "base_public" else None,
                },
            )

        end_time = time.time()
        test_duration = end_time - start_time
        logger.info(f"Tests completed in {test_duration:.2f} seconds")

        test_file_objects = self.create_test_files(test_file_paths=test_files, test_results=test_results)

        file_context.add_test_files(test_file_objects)

        response_msg = ""

        failure_details = TestFile.get_test_failure_details(test_file_objects)
        if failure_details:
            response_msg += f"\n{failure_details}"

        summary = f"\n{TestFile.get_test_summary(test_file_objects)}"
        response_msg += summary

        artifact_changes = []

        logger.info(f"Running tests for {len(args.test_files)} files")
        for test_file in test_file_objects:
            if test_file.file_path not in args.test_files:
                continue

            # Calculate test counts for this file
            passed_count = sum(1 for r in test_file.test_results if r.status == TestStatus.PASSED)
            failed_count = sum(1 for r in test_file.test_results if r.status == TestStatus.FAILED)
            error_count = sum(1 for r in test_file.test_results if r.status == TestStatus.ERROR)
            skipped_count = sum(1 for r in test_file.test_results if r.status == TestStatus.SKIPPED)

            artifact_changes.append(
                ArtifactChange(
                    artifact_id=test_file.file_path,
                    artifact_type="test",
                    change_type="updated",
                    properties={
                        "passed": passed_count,
                        "failed": failed_count,
                        "errors": error_count,
                        "skipped": skipped_count,
                        "total": len(test_file.test_results),
                    },
                    actor="assistant",
                )
            )

        if error_details:
            response_msg += f"\n{error_details}"

        executions = getattr(self._workspace.runtime, "last_test_execution", [])
        current_product_patch_hash = content_hash(file_context.generate_git_patch(ignore_tests=True))
        properties = {"test_source": test_source, "test_origins": origins, "auto_base_public": auto_base_public,
                      "product_patch_hash": current_product_patch_hash,
                      "tested_patch_hash": content_hash(patch),
                      "product_patch": patch if test_source == "base_public" else None,
                      "result_statuses": [result.status.value.lower() for result in test_results],
                      "result_count": len(test_results),
                      "patch_stale": product_patch_hash != current_product_patch_hash}
        if auto_base_public:
            response_msg += "\nTests were modified; verification automatically used the unchanged base_public tests."
        elif (test_source == "workspace"
                and any(value in {"modified", "new"} for value in origins.values())
                and current_product_patch_hash):
            properties["requires_base_public"] = True
            response_msg += "\nTests were modified/added; run base_public verification before finishing."
        if isinstance(executions, list) and executions:
            properties.update({
                "test_execution": executions,
                "return_code": next((x["return_code"] for x in executions if x["return_code"] != 0), 0),
            })
        # A failing public check may predate this patch. Only public material is
        # used here, in the same runtime; official grading caches are never read.
        if test_source == "base_public" and any(r.status in {TestStatus.FAILED, TestStatus.ERROR} for r in test_results):
            from moatless.execution_memory import environment_version
            key = content_hash({"targets": sorted(test_files), "environment": environment_version(self._workspace),
                                "base": base_contents})
            properties["public_baseline_cached"] = key in self._public_baselines
            if key not in self._public_baselines:
                baseline_results = await self._workspace.runtime.run_tests(test_files=test_files, patch="")
                self._public_baselines[key] = {
                    "failed": sorted(r.name for r in baseline_results if r.status in {TestStatus.FAILED, TestStatus.ERROR}),
                    "result_count": len(baseline_results),
                    "execution": getattr(self._workspace.runtime, "last_test_execution", []),
                }
            baseline = self._public_baselines[key]
            properties["public_baseline"] = baseline
            properties["introduced_failures"] = sorted(set(r.name for r in test_results
                if r.status in {TestStatus.FAILED, TestStatus.ERROR}) - set(baseline["failed"]))
        return Observation(message=response_msg, summary=summary, artifact_changes=artifact_changes,
                           properties=properties)  # type: ignore

    def create_test_files(self, test_file_paths: list[str], test_results: list[TestResult]) -> list[TestFile]:
        results_by_file: dict[str | None, list[TestResult]] = {}
        for result in test_results:
            results_by_file.setdefault(result.file_path, []).append(result)

        test_files = []

        # Create TestFile objects for all groups of results with a valid file_path
        for file_path, file_test_results in results_by_file.items():
            if file_path is None:
                # Handle results with no file path separately
                num_results_no_path = len(file_test_results)
                if num_results_no_path > 0:
                    logger.warning(
                        f"Received {num_results_no_path} test results with no associated file path. These cannot be added to the TestFile list."
                    )
                continue

            # Create TestFile for results with a valid file_path
            test_file = TestFile(file_path=file_path, test_results=file_test_results)

            if file_test_results:
                # Log counts for this group
                logger.info(
                    f"Test results for {file_path}: "
                    f"{sum(1 for r in file_test_results if r.status == TestStatus.PASSED)} passed, "
                    f"{sum(1 for r in file_test_results if r.status == TestStatus.FAILED)} failed, "
                    f"{sum(1 for r in file_test_results if r.status == TestStatus.ERROR)} errors, "
                    f"{sum(1 for r in file_test_results if r.status == TestStatus.SKIPPED)} skipped"
                )

                # Log a warning if these results were not for an explicitly requested file
                if file_path not in test_file_paths:
                    logger.warning(f"Received unexpected test results for {file_path}")

            test_files.append(test_file)

        # Ensure TestFile objects exist for requested paths even if they had no results
        processed_paths = {tf.file_path for tf in test_files}
        for test_file_path in test_file_paths:
            if test_file_path not in processed_paths:
                logger.warning(f"No test results found for requested file {test_file_path}")
                test_file = TestFile(file_path=test_file_path, test_results=[])
                test_files.append(test_file)

        return test_files

    @classmethod
    def get_evaluation_criteria(cls, trajectory_length) -> list[str]:
        criteria = [
            "Test Result Evaluation: Analyze test results in conjunction with the proposed code changes.",
            "Test Failures Categorization: Differentiate between minor, foreseeable, and unforeseeable failures.",
            " * Minor, Easily Fixable Failures: Lightly penalize or treat as neutral.",
            " * Foreseeable Failures: Penalize appropriately based on the complexity of the fix.",
            " * Unforeseeable Failures: Penalize very lightly or reward for providing new insights.",
            "Impact of Failures: Consider the overall impact of test failures on the solution's viability.",
            "Iterative Improvement: Encourage fixing minor issues in subsequent iterations.",
            "Explanation Requirement: In your explanation, describe any test failures, their likely causes, and suggest potential next steps.",
        ]
        return criteria

    @classmethod
    def get_reward_scale(cls, trajectory_length) -> list[RewardScaleEntry]:
        return [
            RewardScaleEntry(
                min_value=90,
                max_value=100,
                description="All tests pass successfully, confirming the solution's correctness.",
            ),
            RewardScaleEntry(
                min_value=75,
                max_value=89,
                description="Most tests pass, with minor, easily fixable failures.",
            ),
            RewardScaleEntry(
                min_value=50,
                max_value=74,
                description="Tests have some failures, but they are minor or unforeseeable, and the agent shows understanding in interpreting results.",
            ),
            RewardScaleEntry(
                min_value=25,
                max_value=49,
                description="Tests have noticeable failures; some may have been foreseeable, but the agent can address them with effort.",
            ),
            RewardScaleEntry(
                min_value=0,
                max_value=24,
                description="Tests have significant failures; the agent's interpretation is minimal or incorrect.",
            ),
            RewardScaleEntry(
                min_value=-49,
                max_value=-1,
                description="Tests fail significantly; the agent misinterprets results or shows lack of progress, foreseeable failures are not addressed.",
            ),
            RewardScaleEntry(
                min_value=-100,
                max_value=-50,
                description="The action is counterproductive, demonstrating misunderstanding or causing setbacks, test failures are severe and could have been anticipated.",
            ),
        ]
